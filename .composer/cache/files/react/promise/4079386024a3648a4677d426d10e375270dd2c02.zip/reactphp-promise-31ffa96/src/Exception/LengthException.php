<?php

namespace React\Promise\Exception;

class LengthException extends \LengthException
{
}
